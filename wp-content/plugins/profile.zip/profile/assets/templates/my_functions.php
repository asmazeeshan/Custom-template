<?php

function new_profile_create_db() {

global $wpdb;

$charset_collate = $wpdb->get_charset_collate();

$table_name = $wpdb->prefix . 'profile';

$sql = "CREATE TABLE IF NOT EXISTS $table_name (
    id mediumint(9) NOT NULL AUTO_INCREMENT,
    firstname varchar(255) NOT NULL,
    lastname varchar(255) NOT NULL,
    email varchar(255) NOT NULL,
    phone varchar(255) NOT NULL,
    about varchar(255) NOt NULL,
    created_at datetime NOT NULL,
    PRIMARY KEY  (id)
) $charset_collate;";

require_once( ABSPATH . 'wp-admin/includes/upgrade.php' );
dbDelta( $sql );
}


function insertdata_in_database($firstname, $lastname, $email, $phone, $about){
    global $wpdb;
    $table_name = $wpdb->prefix . 'profile';
    $wpdb->insert($table_name, array(
                'firstname'  =>$firstname,
                'lastname'   => $lastname,
                'email'      => $email,
                'phone'      => $phone,
                'about'      => $about,
                'created_at' => date("Y-m-d H:m:s")
              ),array('%s')
    );
}

function updatedata_in_database($id , $firstname, $lastname, $email, $phone, $about){
    global $wpdb;
    $table_name = $wpdb->prefix . 'profile';
    $data = array(
        'firstname'  =>$firstname,
        'lastname'   => $lastname,
        'email'      => $email,
        'phone'      => $phone,
        'about'      => $about,
        'created_at' => date("Y-m-d H:m:s")
    );
    $where = array(
        'id' => $id
    );
    $wpdb->update($table_name, $data, $where);
    
}